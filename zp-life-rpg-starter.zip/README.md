# ZP LiFE RPG — Starter
Generated 2025-10-21T05:13:45

## Run
- Backend: `cd backend && npm i && npm run dev`
- Frontend: `cd frontend && npm i && npm run dev`

Open http://localhost:5173
