import React, { useEffect, useState } from 'react'
import axios from 'axios'
import HudCard from '../components/HudCard'
import QuestList from '../components/QuestList'
const API = window.__API__

export default function App(){
  const [hud, setHud] = useState(null)
  const [quests, setQuests] = useState([])
  const [loading, setLoading] = useState(true)
  async function load(){
    const [hudRes, qRes] = await Promise.all([
      axios.get(`${API}/api/player/player-1/hud`),
      axios.get(`${API}/api/quests`),
    ])
    setHud(hudRes.data); setQuests(qRes.data); setLoading(false)
  }
  async function complete(id){ await axios.post(`${API}/api/quests/${id}/complete`); await load() }
  useEffect(()=>{ load() }, [])
  if(loading) return <div style={{padding:20}}>Loading…</div>
  return (<div style={{display:'grid',gap:16,padding:16}}>
    <HudCard player={hud.player} kpi={hud.kpi} />
    <QuestList quests={quests} onComplete={complete} />
  </div>)
}
